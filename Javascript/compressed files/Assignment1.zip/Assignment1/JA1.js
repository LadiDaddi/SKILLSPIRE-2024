console.log("Hello World!");
console.log("Loren");
console.log("green");
console.log(2+2);
 let l="loren";
 let a="allen";
console.log(l+" "+a);

for (let i=1; i<=10;i++){
    console.log(i)
};

for (let i=1; i<=5;i++){
    console.log("Skillspire")
};

for (let i=1; i<=10; i++){
    console.log(i*2)  
};

for (let i=0; i<=20; i+=2){
    console.log(i)
};
for (let i=1; i<=20; i+=2){
    console.log(i)
};

for (let i=1; i<=10; i++) {
    if (i%2==0) { 
        console.log("FIZZ");
    }
    else{
    console.log("BUZZ");
    }
}
